





yamst -lu tty0.socket
